# benjisidoko.github.io

Portfolio of Benjamin Emmanuel, product designer and design engineer.

Built by hand with HTML, CSS, and JavaScript. No frameworks, no build step, no dependencies.

## Structure

```
index.html            Landing page
work/*.html           One page per case study
404.html              Not-found page
assets/css/site.css   All styles, design tokens, light and dark themes
assets/js/site.js     Interactions: theme switch, reveals, hero slider, cursor label
assets/img/           Portrait and project screenshots
```

## Adding screenshots

Each case study marks its placeholders with a comment showing the file to add, for example
`assets/img/unitora/investor-dashboard-portfolio-overview.jpg`. Save the image there and swap the
placeholder `<div class="ph">` for the `<img>` in the comment.

## Project covers

Covers are drawn in HTML and CSS in each project's own palette, with illustrative data. Replace a
cover with a real screenshot by swapping its `<div class="cover">` for an `<img>`.

## Details

- Light and dark themes follow the visitor's system setting, with a manual switch
- Page-to-page transitions use the View Transitions API where supported
- All motion respects `prefers-reduced-motion`
