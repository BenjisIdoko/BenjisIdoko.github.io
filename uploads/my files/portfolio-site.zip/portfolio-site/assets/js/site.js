/* Benjamin Emmanuel portfolio: small, dependency-free interactions */
(function () {
  var root = document.documentElement;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* Theme switch: follows the system until the visitor chooses */
  var themeBtn = document.getElementById('theme');
  if (themeBtn) {
    themeBtn.addEventListener('click', function () {
      var current = root.getAttribute('data-theme') ||
        (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
      var next = current === 'dark' ? 'light' : 'dark';
      var apply = function () { root.setAttribute('data-theme', next); };
      if (document.startViewTransition && !reduce) document.startViewTransition(apply); else apply();
      try { localStorage.setItem('bie-theme', next); } catch (e) {}
      themeBtn.setAttribute('aria-label', next === 'dark' ? 'Switch to light theme' : 'Switch to dark theme');
    });
  }

  /* Header turns to glass once the page scrolls */
  var head = document.querySelector('.site-head');
  if (head) {
    var onScroll = function () { head.classList.toggle('scrolled', window.scrollY > 8); };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  /* Reveal cards and timeline rows as they enter the viewport */
  var revealEls = [].slice.call(document.querySelectorAll('[data-reveal]'));
  if ('IntersectionObserver' in window && !reduce) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('in'); });
  }

  /* Count up the numbers in the experience section */
  var metrics = [].slice.call(document.querySelectorAll('[data-count]'));
  if (metrics.length && 'IntersectionObserver' in window && !reduce) {
    var mo = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        var el = e.target, end = parseFloat(el.getAttribute('data-count')), suffix = el.getAttribute('data-suffix') || '';
        var start = null, dur = 1200;
        var step = function (t) {
          if (!start) start = t;
          var p = Math.min((t - start) / dur, 1), eased = 1 - Math.pow(1 - p, 3);
          el.textContent = Math.round(end * eased) + suffix;
          if (p < 1) requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
        mo.unobserve(el);
      });
    }, { threshold: 0.6 });
    metrics.forEach(function (m) { mo.observe(m); });
  }

  /* Hero: glass stage that cycles through featured projects */
  var stage = document.querySelector('[data-stage]');
  if (stage) {
    var screens = [].slice.call(stage.querySelectorAll('.screen'));
    var dots = [].slice.call(stage.querySelectorAll('.dots button'));
    var label = stage.querySelector('[data-stage-label]');
    var sub = stage.querySelector('[data-stage-sub]');
    var i = 0, timer = null;
    var show = function (n) {
      i = (n + screens.length) % screens.length;
      screens.forEach(function (s, k) { s.classList.toggle('on', k === i); s.setAttribute('aria-hidden', k === i ? 'false' : 'true'); });
      dots.forEach(function (d, k) { d.setAttribute('aria-current', k === i ? 'true' : 'false'); });
      if (label) { label.textContent = screens[i].getAttribute('data-name'); label.setAttribute('href', screens[i].getAttribute('data-href')); }
      if (sub) sub.textContent = screens[i].getAttribute('data-sub');
    };
    var play = function () { if (!reduce) { stop(); timer = setInterval(function () { show(i + 1); }, 4200); } };
    var stop = function () { if (timer) clearInterval(timer); timer = null; };
    dots.forEach(function (d, k) { d.addEventListener('click', function () { show(k); play(); }); });
    stage.addEventListener('mouseenter', stop);
    stage.addEventListener('mouseleave', play);
    stage.addEventListener('focusin', stop);
    stage.addEventListener('focusout', play);
    document.addEventListener('visibilitychange', function () { if (document.hidden) stop(); else play(); });
    show(0); play();

    /* Gentle tilt of the glass card toward the pointer */
    var glass = stage.querySelector('.glass');
    if (glass && !reduce && matchMedia('(pointer: fine)').matches) {
      stage.addEventListener('mousemove', function (e) {
        var r = stage.getBoundingClientRect();
        var x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
        glass.style.transform = 'perspective(900px) rotateY(' + (x * 6) + 'deg) rotateX(' + (-y * 6) + 'deg)';
      });
      stage.addEventListener('mouseleave', function () { glass.style.transform = ''; });
    }
  }

  /* Cursor label over project cards (mouse only) */
  var cursor = document.querySelector('.cursor');
  if (cursor && matchMedia('(pointer: fine)').matches) {
    var cx = 0, cy = 0, tx = 0, ty = 0, raf = null;
    var loop = function () {
      cx += (tx - cx) * 0.22; cy += (ty - cy) * 0.22;
      cursor.style.left = cx + 'px'; cursor.style.top = cy + 'px';
      raf = (Math.abs(tx - cx) > 0.3 || Math.abs(ty - cy) > 0.3) ? requestAnimationFrame(loop) : null;
    };
    [].slice.call(document.querySelectorAll('.card')).forEach(function (card) {
      card.addEventListener('mouseenter', function (e) { tx = cx = e.clientX; ty = cy = e.clientY; loop(); cursor.textContent = card.getAttribute('data-cursor') || 'View case study'; cursor.classList.add('on'); });
      card.addEventListener('mousemove', function (e) { tx = e.clientX; ty = e.clientY; if (!raf) raf = requestAnimationFrame(loop); });
      card.addEventListener('mouseleave', function () { cursor.classList.remove('on'); });
    });
  }

  /* Copy email with a small confirmation */
  var toast = document.querySelector('.toast');
  [].slice.call(document.querySelectorAll('[data-copy]')).forEach(function (btn) {
    btn.addEventListener('click', function () {
      var text = btn.getAttribute('data-copy');
      var done = function () {
        if (!toast) return;
        toast.textContent = 'Email copied';
        toast.classList.add('on');
        setTimeout(function () { toast.classList.remove('on'); }, 1800);
      };
      if (navigator.clipboard) navigator.clipboard.writeText(text).then(done, function () { window.location.href = 'mailto:' + text; });
      else window.location.href = 'mailto:' + text;
    });
  });

  /* Project pages: highlight the current section in the side index */
  var tocLinks = [].slice.call(document.querySelectorAll('.toc a'));
  if (tocLinks.length && 'IntersectionObserver' in window) {
    var to = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) tocLinks.forEach(function (l) { l.classList.toggle('on', l.getAttribute('href') === '#' + e.target.id); });
      });
    }, { rootMargin: '-30% 0px -60% 0px' });
    tocLinks.forEach(function (l) { var t = document.querySelector(l.getAttribute('href')); if (t) to.observe(t); });
  }
})();

/* Scale each cover screen to its device frame */
(function () {
  var fits = [].slice.call(document.querySelectorAll('.fit[data-w]'));
  if (!fits.length) return;
  var size = function (f) {
    var k = f.clientWidth / parseFloat(f.getAttribute('data-w'));
    if (k > 0) f.style.setProperty('--k', k);
  };
  fits.forEach(size);
  if ('ResizeObserver' in window) {
    var ro = new ResizeObserver(function (entries) { entries.forEach(function (e) { size(e.target); }); });
    fits.forEach(function (f) { ro.observe(f); });
  } else {
    window.addEventListener('resize', function () { fits.forEach(size); });
  }
})();

/* Hero: one component shown as design, code, then live */
(function () {
  var studio = document.querySelector('[data-studio]');
  if (!studio) return;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var modes = ['design', 'code', 'live'];
  var btns = [].slice.call(studio.querySelectorAll('.seg button'));
  var ind = studio.querySelector('.seg-ind');
  var wrap = studio.querySelector('.cmp-wrap');
  var val = studio.querySelector('[data-val]');
  var prog = studio.querySelector('.prog i');
  var caption = studio.querySelector('[data-caption]');
  var captions = {
    design: 'Designed in Figma: spacing, tokens, states.',
    code: 'Built as a typed React component.',
    live: 'Shipped and working, exactly as designed.'
  };
  var i = 0, timer = null, CYCLE = 4600;

  var moveInd = function (btn) {
    if (!ind || !btn) return;
    ind.style.width = btn.offsetWidth + 'px';
    ind.style.transform = 'translateX(' + (btn.offsetLeft - 3) + 'px)';
  };
  var countUp = function () {
    if (!val || reduce) return;
    var end = 4250000, start = null, dur = 1300;
    var step = function (t) {
      if (!start) start = t;
      var p = Math.min((t - start) / dur, 1), e = 1 - Math.pow(1 - p, 3);
      val.textContent = '₦' + Math.round(end * e).toLocaleString('en-US');
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };
  var set = function (n) {
    i = (n + modes.length) % modes.length;
    var m = modes[i];
    studio.setAttribute('data-mode', m);
    btns.forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-mode') === m ? 'true' : 'false'); });
    moveInd(btns[i]);
    if (caption) caption.textContent = captions[m];
    if (m === 'live') {
      wrap.classList.remove('play'); void wrap.offsetWidth; wrap.classList.add('play');
      countUp();
    } else if (val) {
      val.textContent = '₦4,250,000';
    }
    if (prog) { prog.classList.remove('run'); void prog.offsetWidth; if (timer) prog.classList.add('run'); }
  };
  var stop = function () { if (timer) clearInterval(timer); timer = null; if (prog) prog.classList.remove('run'); };
  var play = function () {
    if (reduce) return;
    stop();
    timer = setInterval(function () { set(i + 1); }, CYCLE);
    if (prog) { void prog.offsetWidth; prog.classList.add('run'); }
  };
  btns.forEach(function (b, k) { b.addEventListener('click', function () { set(k); play(); }); });
  studio.addEventListener('mouseenter', stop);
  studio.addEventListener('mouseleave', play);
  studio.addEventListener('focusin', stop);
  document.addEventListener('visibilitychange', function () { if (document.hidden) stop(); else play(); });
  window.addEventListener('resize', function () { moveInd(btns[i]); });
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { moveInd(btns[i]); });
  set(0); play();
})();
